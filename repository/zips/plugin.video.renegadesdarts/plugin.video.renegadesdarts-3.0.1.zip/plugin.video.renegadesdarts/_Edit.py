import xbmcaddon

MainBase = 'http://bit.ly/2sUd39O'
addon = xbmcaddon.Addon('plugin.video.renegadesdarts')