import xbmcaddon

MainBase = 'http://bit.ly/2gMHLjb'
addon = xbmcaddon.Addon('plugin.video.helpfiles')